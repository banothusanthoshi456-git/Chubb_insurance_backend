package com.example.claims.api;

import com.example.claims.domain.ClaimsStaff;
import com.example.claims.repository.ClaimsStaffRepository;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@RestController
@RequestMapping("/api/staff")
public class StaffController {
    private final ClaimsStaffRepository repository;
    public StaffController(ClaimsStaffRepository repository) { this.repository = repository; }

    @GetMapping public List<ClaimsStaff> list() { return repository.findAll(); }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ClaimsStaff create(@Valid @RequestBody StaffRequest request) {
        if (repository.findAll().stream().anyMatch(s -> s.getEmail().equalsIgnoreCase(request.email())))
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Staff email already exists");
        return repository.save(new ClaimsStaff(request.fullName(), request.email().toLowerCase()));
    }

    public record StaffRequest(@NotBlank String fullName, @NotBlank @Email String email) {}
}
