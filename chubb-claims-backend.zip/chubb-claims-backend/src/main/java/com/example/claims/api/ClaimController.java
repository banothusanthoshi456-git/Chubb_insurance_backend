package com.example.claims.api;

import com.example.claims.api.dto.*;
import com.example.claims.domain.ClaimStatus;
import com.example.claims.service.ClaimService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/claims")
public class ClaimController {
    private final ClaimService service;
    public ClaimController(ClaimService service) { this.service = service; }

    @PostMapping public ClaimResponse submit(@Valid @RequestBody SubmitClaimRequest request) { return service.submit(request); }
    @GetMapping("/{id}") public ClaimResponse get(@PathVariable Long id) { return service.get(id); }
    @GetMapping public List<ClaimResponse> list(
        @RequestParam(required=false) ClaimStatus status,
        @RequestParam(required=false) Long staffId) { return service.list(status, staffId); }
    @PutMapping("/{id}/assignment") public ClaimResponse assign(@PathVariable Long id, @Valid @RequestBody AssignClaimRequest request) {
        return service.assign(id, request);
    }
    @PostMapping("/{id}/decision") public ClaimResponse decide(@PathVariable Long id, @Valid @RequestBody DecisionRequest request) {
        return service.decide(id, request);
    }
    @GetMapping("/dashboard") public Map<String,Object> dashboard() { return service.dashboard(); }
}
