package com.example.claims.api.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public record SubmitClaimRequest(
    @NotBlank @Size(max=120) String claimantName,
    @NotBlank @Email String claimantEmail,
    @NotBlank String claimantPhone,
    @NotBlank @Size(max=80) String market,
    @NotBlank @Size(max=80) String claimType,
    @NotNull @DecimalMin(value="0.01") BigDecimal claimedAmount,
    @Size(max=2000) String description
) {}
