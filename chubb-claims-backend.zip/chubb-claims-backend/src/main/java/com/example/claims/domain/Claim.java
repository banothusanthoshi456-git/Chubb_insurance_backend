package com.example.claims.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "claims", indexes = {
    @Index(name = "idx_claim_status", columnList = "status"),
    @Index(name = "idx_claim_created", columnList = "createdAt")
})
public class Claim {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, unique = true, length = 30)
    private String claimNumber;
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    private Claimant claimant;
    @ManyToOne(fetch = FetchType.EAGER)
    private ClaimsStaff assignedStaff;
    @Column(nullable = false, length = 80)
    private String market;
    @Column(nullable = false, length = 80)
    private String claimType;
    @Column(nullable = false, precision = 14, scale = 2)
    private BigDecimal claimedAmount;
    @Column(precision = 14, scale = 2)
    private BigDecimal approvedAmount;
    @Column(length = 2000)
    private String description;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 30)
    private ClaimStatus status = ClaimStatus.SUBMITTED;
    @Column(length = 2000)
    private String decisionNotes;
    @Column(nullable = false)
    private Instant createdAt = Instant.now();
    @Column(nullable = false)
    private Instant updatedAt = Instant.now();

    protected Claim() {}
    public Claim(String claimNumber, Claimant claimant, String market, String claimType,
                 BigDecimal claimedAmount, String description) {
        this.claimNumber = claimNumber; this.claimant = claimant; this.market = market;
        this.claimType = claimType; this.claimedAmount = claimedAmount; this.description = description;
        this.status = ClaimStatus.SUBMITTED; this.createdAt = Instant.now(); this.updatedAt = Instant.now();
    }
    @PreUpdate void onUpdate() { updatedAt = Instant.now(); }
    public Long getId() { return id; }
    public String getClaimNumber() { return claimNumber; }
    public Claimant getClaimant() { return claimant; }
    public ClaimsStaff getAssignedStaff() { return assignedStaff; }
    public String getMarket() { return market; }
    public String getClaimType() { return claimType; }
    public BigDecimal getClaimedAmount() { return claimedAmount; }
    public BigDecimal getApprovedAmount() { return approvedAmount; }
    public String getDescription() { return description; }
    public ClaimStatus getStatus() { return status; }
    public String getDecisionNotes() { return decisionNotes; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
    public void assign(ClaimsStaff staff) { this.assignedStaff = staff; }
    public void transition(ClaimStatus status) { this.status = status; }
    public void decide(ClaimStatus status, BigDecimal amount, String notes) {
        this.status = status; this.approvedAmount = amount; this.decisionNotes = notes;
    }
    public void setDecisionNotes(String notes) { this.decisionNotes = notes; }
}
