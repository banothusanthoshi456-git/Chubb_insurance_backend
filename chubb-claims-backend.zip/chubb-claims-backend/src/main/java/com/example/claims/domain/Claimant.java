package com.example.claims.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "claimants")
public class Claimant {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank @Size(max = 120)
    private String fullName;
    @Email @NotBlank
    @Column(nullable = false, unique = true)
    private String email;
    @NotBlank
    private String phone;

    protected Claimant() {}
    public Claimant(String fullName, String email, String phone) {
        this.fullName = fullName; this.email = email; this.phone = phone;
    }
    public Long getId() { return id; }
    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public void setFullName(String v) { fullName = v; }
    public void setEmail(String v) { email = v; }
    public void setPhone(String v) { phone = v; }
}
