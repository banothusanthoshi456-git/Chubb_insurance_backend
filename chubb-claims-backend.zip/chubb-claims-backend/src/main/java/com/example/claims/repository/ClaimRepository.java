package com.example.claims.repository;

import com.example.claims.domain.Claim;
import com.example.claims.domain.ClaimStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface ClaimRepository extends JpaRepository<Claim, Long> {
    Optional<Claim> findByClaimNumber(String claimNumber);
    List<Claim> findByStatus(ClaimStatus status);
    List<Claim> findByAssignedStaff_Id(Long staffId);
    long countByAssignedStaff_IdAndStatusIn(Long staffId, List<ClaimStatus> statuses);
}
