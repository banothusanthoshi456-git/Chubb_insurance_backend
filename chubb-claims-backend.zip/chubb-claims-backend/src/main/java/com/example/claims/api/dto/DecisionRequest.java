package com.example.claims.api.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public record DecisionRequest(
    @NotNull Decision decision,
    @DecimalMin(value="0.00") BigDecimal approvedAmount,
    @NotBlank @Size(max=2000) String notes
) {
    public enum Decision { APPROVE, REJECT, REQUEST_MORE_INFO, SETTLE }
}
