package com.example.claims.domain;

public enum ClaimStatus {
    SUBMITTED, UNDER_REVIEW, MORE_INFO_REQUIRED, APPROVED, REJECTED, SETTLED
}
