package com.example.claims.service;

import com.example.claims.api.dto.*;
import com.example.claims.domain.*;
import com.example.claims.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import java.math.BigDecimal;
import java.util.*;

@Service
public class ClaimService {
    private final ClaimRepository claims;
    private final ClaimantRepository claimants;
    private final ClaimsStaffRepository staff;
    public ClaimService(ClaimRepository claims, ClaimantRepository claimants, ClaimsStaffRepository staff) {
        this.claims = claims; this.claimants = claimants; this.staff = staff;
    }

    @Transactional
    public ClaimResponse submit(SubmitClaimRequest req) {
        Claimant claimant = claimants.findByEmail(req.claimantEmail().toLowerCase())
            .orElseGet(() -> claimants.save(new Claimant(req.claimantName(), req.claimantEmail().toLowerCase(), req.claimantPhone())));
        String number = "CLM-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        Claim claim = new Claim(number, claimant, req.market(), req.claimType(), req.claimedAmount(), req.description());
        return ClaimResponse.from(claims.save(claim));
    }
    @Transactional(readOnly = true)
    public ClaimResponse get(Long id) { return ClaimResponse.from(requireClaim(id)); }
    @Transactional(readOnly = true)
    public List<ClaimResponse> list(ClaimStatus status, Long staffId) {
        List<Claim> found;
        if (status != null) found = claims.findByStatus(status);
        else if (staffId != null) found = claims.findByAssignedStaff_Id(staffId);
        else found = claims.findAll();
        return found.stream().map(ClaimResponse::from).toList();
    }
    @Transactional
    public ClaimResponse assign(Long claimId, AssignClaimRequest req) {
        Claim claim = requireClaim(claimId);
        ClaimsStaff officer = staff.findById(req.staffId())
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Claims staff not found"));
        if (!officer.isActive()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Staff member is inactive");
        if (claim.getStatus() == ClaimStatus.APPROVED || claim.getStatus() == ClaimStatus.REJECTED || claim.getStatus() == ClaimStatus.SETTLED)
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Closed claims cannot be reassigned");
        claim.assign(officer);
        if (claim.getStatus() == ClaimStatus.SUBMITTED) claim.transition(ClaimStatus.UNDER_REVIEW);
        return ClaimResponse.from(claims.save(claim));
    }
    @Transactional
    public ClaimResponse decide(Long id, DecisionRequest req) {
        Claim claim = requireClaim(id);
        if (claim.getAssignedStaff() == null) throw new ResponseStatusException(HttpStatus.CONFLICT, "Assign a claims officer before reviewing");
        if (claim.getStatus() == ClaimStatus.REJECTED || claim.getStatus() == ClaimStatus.SETTLED)
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Claim is already closed");
        if (claim.getStatus() == ClaimStatus.APPROVED && req.decision() != DecisionRequest.Decision.SETTLE)
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Approved claims can only be settled");
        switch (req.decision()) {
            case APPROVE -> {
                if (req.approvedAmount() == null || req.approvedAmount().compareTo(BigDecimal.ZERO) <= 0)
                    throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "A positive approvedAmount is required");
                if (req.approvedAmount().compareTo(claim.getClaimedAmount()) > 0)
                    throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Approved amount cannot exceed claimed amount");
                claim.decide(ClaimStatus.APPROVED, req.approvedAmount(), req.notes());
            }
            case REJECT -> claim.decide(ClaimStatus.REJECTED, BigDecimal.ZERO, req.notes());
            case REQUEST_MORE_INFO -> { claim.transition(ClaimStatus.MORE_INFO_REQUIRED); claim.setDecisionNotes(req.notes()); }
            case SETTLE -> {
                if (claim.getStatus() != ClaimStatus.APPROVED)
                    throw new ResponseStatusException(HttpStatus.CONFLICT, "Only approved claims can be settled");
                claim.transition(ClaimStatus.SETTLED); claim.setDecisionNotes(req.notes());
            }
        }
        return ClaimResponse.from(claims.save(claim));
    }
    @Transactional(readOnly = true)
    public Map<String, Object> dashboard() {
        List<Claim> all = claims.findAll();
        BigDecimal outstanding = all.stream()
            .filter(c -> !List.of(ClaimStatus.REJECTED, ClaimStatus.SETTLED).contains(c.getStatus()))
            .map(Claim::getClaimedAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal approved = all.stream().filter(c -> c.getApprovedAmount() != null)
            .map(Claim::getApprovedAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
        Map<String, Long> byStatus = new LinkedHashMap<>();
        for (ClaimStatus s : ClaimStatus.values()) byStatus.put(s.name(), all.stream().filter(c -> c.getStatus() == s).count());
        return Map.of("totalClaims", all.size(), "claimsByStatus", byStatus,
            "outstandingLiabilityExposure", outstanding, "totalApprovedAmount", approved);
    }
    private Claim requireClaim(Long id) {
        return claims.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Claim not found"));
    }
}
