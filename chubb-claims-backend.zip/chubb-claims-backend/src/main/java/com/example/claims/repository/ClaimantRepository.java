package com.example.claims.repository;
import com.example.claims.domain.Claimant;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
public interface ClaimantRepository extends JpaRepository<Claimant, Long> {
    Optional<Claimant> findByEmail(String email);
}
