# Claims Management Backend (Java 17 / Spring Boot)

A runnable starter implementation for the Chubb APAC claims assessment. It demonstrates claim submission, officer assignment, claim review/decisions, status filtering, and a liability dashboard.

## Why this design
- **Start as a modular monolith**: the assessment asks for a focused working product and gives no operational reason to introduce distributed-service complexity. Domain packages are separated so they can be extracted later if scale/team boundaries justify it.
- **Relational model**: claimant, claims staff, and claim are separate entities. Claims reference claimants and optional assigned staff.
- **REST first**: the required workflows are request/response operations. Kafka is intentionally not made a runtime dependency in this first slice; add events when a real downstream consumer or asynchronous requirement exists.
- **H2 for quick local startup**: easy to demo. Swap to PostgreSQL/MySQL for production.
- **State transitions are validated**: closed claims cannot be reassigned or decided again; only assigned claims can be reviewed; approval amount must be positive and cannot exceed claimed amount.
- **Liability exposure**: dashboard sums claimed amounts for claims not rejected or settled. This is a simple assessment definition; clarify business rules with stakeholders in production.

## Requirements
- JDK 17+
- Maven 3.9+ (or use `./mvnw` after adding a Maven wrapper)

## Run
```bash
mvn spring-boot:run
```
API starts at `http://localhost:8080`.
H2 console: `http://localhost:8080/h2-console`
- JDBC URL: `jdbc:h2:mem:claimsdb`
- User: `sa`
- Password: blank

Health: `http://localhost:8080/actuator/health`

## API walkthrough

### 1. List seeded staff
```bash
curl http://localhost:8080/api/staff
```
Two demo officers are seeded on startup.

### 2. Submit a claim
```bash
curl -X POST http://localhost:8080/api/claims \
  -H 'Content-Type: application/json' \
  -d '{
    "claimantName":"Priya Sharma",
    "claimantEmail":"priya@example.com",
    "claimantPhone":"+91-9000000000",
    "market":"India",
    "claimType":"Motor",
    "claimedAmount":125000.00,
    "description":"Vehicle damage after an accident"
  }'
```
Response includes `id` and `claimNumber`. Use the returned numeric `id` in subsequent calls.

### 3. Assign a claims officer (replace `1` with claim id; `1` is a seeded staff id on a fresh DB)
```bash
curl -X PUT http://localhost:8080/api/claims/1/assignment \
  -H 'Content-Type: application/json' -d '{"staffId":1}'
```
Status moves from `SUBMITTED` to `UNDER_REVIEW`.

### 4. Approve
```bash
curl -X POST http://localhost:8080/api/claims/1/decision \
  -H 'Content-Type: application/json' \
  -d '{"decision":"APPROVE","approvedAmount":100000.00,"notes":"Approved based on submitted evidence"}'
```
Other decisions: `REJECT`, `REQUEST_MORE_INFO`, `SETTLE` (settlement is allowed only after approval).

### 5. Query
```bash
curl 'http://localhost:8080/api/claims'
curl 'http://localhost:8080/api/claims?status=UNDER_REVIEW'
curl 'http://localhost:8080/api/claims?staffId=1'
curl 'http://localhost:8080/api/claims/1'
curl 'http://localhost:8080/api/claims/dashboard'
```

## Main endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/claims` | Submit a claim |
| GET | `/api/claims` | List all; optional `status` or `staffId` filter |
| GET | `/api/claims/{id}` | Claim details |
| PUT | `/api/claims/{id}/assignment` | Assign staff |
| POST | `/api/claims/{id}/decision` | Approve/reject/request information/settle |
| GET | `/api/claims/dashboard` | Status counts and liability totals |
| GET | `/api/staff` | List staff |
| POST | `/api/staff` | Create staff |
| GET | `/actuator/health` | Health check |

## Assessment priorities / trade-offs
1. Deliver the end-to-end core path: submit -> assign -> decide -> dashboard.
2. Explain why this is one deployable service for a time-boxed exercise rather than premature microservices.
3. Keep business logic in `ClaimService`, not controllers.
4. Use DTOs and bean validation at API boundaries.
5. Use database transactions for multi-step operations.
6. For production: authentication/role-based authorization, audit trail, document upload/storage, idempotency, optimistic locking, pagination, migrations (Flyway), observability, PII masking, and integration tests.
7. If Kafka is required in a follow-up: publish `ClaimSubmitted`, `ClaimAssigned`, and `ClaimDecisionRecorded` events through a transactional outbox. The outbox avoids the database-commit/Kafka-publish dual-write problem. Do not claim the current project publishes Kafka events.

## Current limitations
- No authentication/authorization is configured; do not expose this demo to the public internet.
- H2 is in-memory and data resets on restart.
- No document attachment storage, email notifications, or event broker.
- Claim number uses a UUID-derived identifier suitable for a demo; use a database-backed sequence or stronger collision controls for production.
